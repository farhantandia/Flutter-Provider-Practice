const String kApiHost = 'api.openweathermap.org';
const String kIconHost = 'www.openweathermap.org';
const String kUnit = 'metric';
const String kLimit = '1';

const int kWarmOrNot = 20;
