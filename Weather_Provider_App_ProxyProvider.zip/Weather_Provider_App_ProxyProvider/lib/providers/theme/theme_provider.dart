import 'package:flutter/material.dart';
import 'package:weather_provider_app/constants/constants.dart';

import 'package:weather_provider_app/providers/weather/weather_provider.dart';

import 'package:equatable/equatable.dart';
part 'theme_state.dart';

class ThemeProvider {
  final WeatherProvider wp;

  ThemeProvider({required this.wp});

  ThemeState get state {
    if (wp.state.weather.temp > kWarmOrNot) {
      return ThemeState();
    } else {
      return ThemeState(appTheme: AppTheme.dark);
    }
  }
}
