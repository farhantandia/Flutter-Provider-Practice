package com.example.weather_provider_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
